package br.edu.cs.poo.ac.ordem.telas;

import javax.swing.*;

import br.edu.cs.poo.ac.ordem.entidades.*;
import br.edu.cs.poo.ac.ordem.mediators.EquipamentoMediator;
import br.edu.cs.poo.ac.ordem.mediators.OrdemServicoMediator;
import br.edu.cs.poo.ac.ordem.mediators.ResultadoMediator;

import java.awt.*;
import java.time.LocalDateTime;

public class TelaCliente extends JFrame {

    private JTextField txtCPF, txtNome, txtNumeroOS, txtPrazo, txtValor;
    private JTextField txtEquipId, txtVendedor, txtMotivo;

    private OrdemServicoMediator mediator = OrdemServicoMediator.getInstancia();
    private EquipamentoMediator equipamentoMediator = EquipamentoMediator.getInstancia();

    public TelaCliente() {

        setTitle("Gest�o de Ordem de Servi�o");
        setSize(500, 450);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 20, 100, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(120, 20, 200, 25);
        add(txtNome);

        JLabel lblCPF = new JLabel("CPF/CNPJ:");
        lblCPF.setBounds(20, 60, 100, 25);
        add(lblCPF);

        txtCPF = new JTextField();
        txtCPF.setBounds(120, 60, 200, 25);
        add(txtCPF);

        JLabel lblEquip = new JLabel("Equipamento (Serial):");
        lblEquip.setBounds(20, 100, 200, 25);
        add(lblEquip);

        txtEquipId = new JTextField();
        txtEquipId.setBounds(180, 100, 150, 25);
        add(txtEquipId);

        JLabel lblPrazo = new JLabel("Prazo (dias):");
        lblPrazo.setBounds(20, 140, 120, 25);
        add(lblPrazo);

        txtPrazo = new JTextField();
        txtPrazo.setBounds(140, 140, 120, 25);
        add(txtPrazo);

        JLabel lblValor = new JLabel("Valor:");
        lblValor.setBounds(20, 180, 80, 25);
        add(lblValor);

        txtValor = new JTextField();
        txtValor.setBounds(120, 180, 120, 25);
        add(txtValor);

        JLabel lblVend = new JLabel("Vendedor:");
        lblVend.setBounds(20, 220, 100, 25);
        add(lblVend);

        txtVendedor = new JTextField();
        txtVendedor.setBounds(120, 220, 200, 25);
        add(txtVendedor);

        JButton btnIncluir = new JButton("Incluir OS");
        btnIncluir.setBounds(20, 260, 120, 30);
        add(btnIncluir);

        JButton btnBuscar = new JButton("Buscar OS");
        btnBuscar.setBounds(160, 260, 120, 30);
        add(btnBuscar);

        JLabel lblNumOS = new JLabel("N�mero OS:");
        lblNumOS.setBounds(20, 310, 120, 25);
        add(lblNumOS);

        txtNumeroOS = new JTextField();
        txtNumeroOS.setBounds(120, 310, 200, 25);
        add(txtNumeroOS);

        JLabel lblMotivo = new JLabel("Motivo cancel:");
        lblMotivo.setBounds(20, 350, 120, 25);
        add(lblMotivo);

        txtMotivo = new JTextField();
        txtMotivo.setBounds(140, 350, 200, 25);
        add(txtMotivo);

        JButton btnCancelar = new JButton("Cancelar OS");
        btnCancelar.setBounds(20, 380, 140, 30);
        add(btnCancelar);

        JButton btnFechar = new JButton("Fechar OS");
        btnFechar.setBounds(180, 380, 140, 30);
        add(btnFechar);

        btnIncluir.addActionListener(e -> incluirOS());
        btnBuscar.addActionListener(e -> buscarOS());
        btnCancelar.addActionListener(e -> cancelarOS());
        btnFechar.addActionListener(e -> fecharOS());
    }

    private void incluirOS() {
        try {
            Cliente c = new Cliente(txtNome.getText(), txtCPF.getText());
            Equipamento equip = equipamentoMediator.buscarDesktop(txtEquipId.getText());

            if (equip == null) {
                equip = equipamentoMediator.buscarNotebook(txtEquipId.getText());
            }

            DadosOrdemServico dados = new DadosOrdemServico(
                c,
                null,
                equip,
                LocalDateTime.now(),
                Integer.parseInt(txtPrazo.getText()),
                Double.parseDouble(txtValor.getText()),
                txtVendedor.getText()
            );

            ResultadoMediator r = mediator.incluir(dados);
            JOptionPane.showMessageDialog(this, r.toString());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }

    private void buscarOS() {
        OrdemServico os = mediator.buscar(txtNumeroOS.getText());
        if (os == null) {
            JOptionPane.showMessageDialog(this, "OS n�o encontrada!");
            return;
        }
        JOptionPane.showMessageDialog(this, "Status: " + os.getStatus());
    }

    private void cancelarOS() {
        ResultadoMediator r = mediator.cancelar(
            txtNumeroOS.getText(),
            txtMotivo.getText(),
            LocalDateTime.now()
        );
        JOptionPane.showMessageDialog(this, r.toString());
    }

    private void fecharOS() {
        FechamentoOrdemServico f = new FechamentoOrdemServico(
            txtNumeroOS.getText(),
            LocalDateTime.now(),
            true
        );

        ResultadoMediator r = mediator.fechar(f);
        JOptionPane.showMessageDialog(this, r.toString());
    }

    public static void main(String[] args) {
        new TelaCliente().setVisible(true);
    }
}
