package br.edu.cs.poo.ac.ordem.daos;

import br.edu.cs.poo.ac.ordem.entidades.Notebook;
import br.edu.cs.poo.ac.utils.Registro;

public class NotebookDAO extends DAOGenerico {

    @Override
    protected Class<? extends Registro> getClasseEntidade() {
        return (Class<? extends Registro>) Notebook.class;
    }

    public Notebook buscar(String idTipoSerial) {
        return (Notebook) super.buscar(idTipoSerial);
    }

    public boolean incluir(Notebook notebook) {
        return super.incluir(notebook);
    }

    public boolean alterar(Notebook notebook) {
        return super.alterar(notebook);
    }

    public boolean excluir(String idTipoSerial) {
        return super.excluir(idTipoSerial);
    }

    public Notebook[] buscarTodos() {
        Registro[] lista = super.buscarTodos();
        Notebook[] retorno = new Notebook[lista.length];
        for (int i = 0; i < lista.length; i++) {
            retorno[i] = (Notebook) lista[i];
        }
        return retorno;
    }
}
