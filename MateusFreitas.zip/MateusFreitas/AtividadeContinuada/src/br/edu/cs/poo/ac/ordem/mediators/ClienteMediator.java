package br.edu.cs.poo.ac.ordem.mediators;

import br.edu.cs.poo.ac.ordem.daos.ClienteDAO;
import br.edu.cs.poo.ac.ordem.entidades.Cliente;
import br.edu.cs.poo.ac.utils.ListaString;
import br.edu.cs.poo.ac.utils.ValidadorCPFCNPJ;
import br.edu.cs.poo.ac.utils.ResultadoValidacaoCPFCNPJ;
import br.edu.cs.poo.ac.utils.ErroValidacaoCPFCNPJ;

import java.util.HashMap;
import java.util.Map;

public class ClienteMediator {

	
    private static ClienteMediator instancia;
    
    private ClienteDAO clienteDAO;
    
    private Map<String, Cliente> baseClientes;

    private ClienteMediator() {
        this.clienteDAO = new ClienteDAO();
        this.baseClientes = new HashMap<>();
    }

    public static ClienteMediator getInstancia() {
        if (instancia == null) {
            instancia = new ClienteMediator();
        }
        return instancia;
    }

    public ResultadoMediator incluir(Cliente cliente) {
        ResultadoMediator resultado = validar(cliente);
        if (!resultado.isValidado()) {
            return resultado;
        }

        if (baseClientes.containsKey(cliente.getCpfCnpj())) {
            ListaString erros = new ListaString();
            erros.adicionar("Cliente j� existe com este CPF/CNPJ");
            return new ResultadoMediator(true, false, erros);
        }

        baseClientes.put(cliente.getCpfCnpj(), cliente);
        return new ResultadoMediator(true, true, new ListaString());
    }

    public ResultadoMediator alterar(Cliente cliente) {
        ResultadoMediator resultado = validar(cliente);
        if (!resultado.isValidado()) {
            return resultado;
        }

        if (!baseClientes.containsKey(cliente.getCpfCnpj())) {
            ListaString erros = new ListaString();
            erros.adicionar("Cliente n�o encontrado para altera��o");
            return new ResultadoMediator(true, false, erros);
        }

        baseClientes.put(cliente.getCpfCnpj(), cliente);
        return new ResultadoMediator(true, true, new ListaString());
    }

    public ResultadoMediator excluir(String cpfCnpj) {
        if (!baseClientes.containsKey(cpfCnpj)) {
            ListaString erros = new ListaString();
            erros.adicionar("Cliente n�o encontrado para exclus�o");
            return new ResultadoMediator(true, false, erros);
        }

        baseClientes.remove(cpfCnpj);
        return new ResultadoMediator(true, true, new ListaString());
    }

    public Cliente buscar(String cpfCnpj) {
        return baseClientes.get(cpfCnpj);
    }

    

    public ResultadoMediator validar(Cliente cliente) {
        ListaString erros = new ListaString();

        if (cliente == null) {
            erros.adicionar("Cliente � nulo");
            return new ResultadoMediator(false, false, erros);
        }

        if (cliente.getNome() == null || cliente.getNome().trim().isEmpty()) {
            erros.adicionar("Nome do cliente � obrigat�rio");
        }

        // Valida CPF/CNPJ
        ResultadoValidacaoCPFCNPJ validador = ValidadorCPFCNPJ.validarCPFCNPJ(cliente.getCpfCnpj());
        if (validador.getErroValidacao() != null) {
            erros.adicionar(validador.getErroValidacao().getMensagem());
        }

        boolean validado = erros.tamanho() == 0;
        return new ResultadoMediator(validado, false, erros);
    }
}
