package br.edu.cs.poo.ac.ordem.testes;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import br.edu.cs.poo.ac.ordem.entidades.Cliente;

class ComparadoraObjetosSerial {
    static boolean compareObjectsSerial(Cliente cliente, Cliente clienteBuscado) {
        ByteArrayOutputStream  bos1 = null;
        ByteArrayOutputStream  bos2 = null;
        ObjectOutputStream oos1 = null;
        ObjectOutputStream oos2 = null;
        boolean ret = true;
        try {
            bos1 = new ByteArrayOutputStream();
            bos2 = new ByteArrayOutputStream();
            oos1 = new ObjectOutputStream(bos1);
            oos2 = new ObjectOutputStream(bos2);
            oos1.writeObject(cliente);
            oos2.writeObject(clienteBuscado);
            byte[] b1 = bos1.toByteArray();
            byte[] b2 = bos2.toByteArray();
            for (int i=0; i<b1.length; i++) {
                if (b2[i] != b1[i]) {
                    ret = false;
                    break;
                }
                i++;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return ret;
    }
}