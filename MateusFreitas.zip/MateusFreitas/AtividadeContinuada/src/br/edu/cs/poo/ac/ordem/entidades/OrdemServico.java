package br.edu.cs.poo.ac.ordem.entidades;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import br.edu.cs.poo.ac.utils.Registro;

public class OrdemServico implements Serializable, Registro {

    private static final long serialVersionUID = 1L;

    private Cliente cliente;
    private PrecoBase precoBase;
    private Equipamento equipamento;
    private LocalDateTime dataHoraAbertura;
    private int prazoEmDias;
    private double valor;

    private FechamentoOrdemServico dadosFechamento;
    private LocalDateTime dataHoraCancelamento;
    private String motivoCancelamento;
    private StatusOrdem status;

    public OrdemServico(Cliente cliente, PrecoBase precoBase,
                        Equipamento equipamento, LocalDateTime dataHoraAbertura,
                        int prazoEmDias, double valor) {

        this.cliente = cliente;
        this.precoBase = precoBase;
        this.equipamento = equipamento;
        this.dataHoraAbertura = dataHoraAbertura;
        this.prazoEmDias = prazoEmDias;
        this.valor = valor;

        this.status = StatusOrdem.ABERTA;
    }

    public Cliente getCliente() { return cliente; }
    public PrecoBase getPrecoBase() { return precoBase; }
    public Equipamento getEquipamento() { return equipamento; }
    public LocalDateTime getDataHoraAbertura() { return dataHoraAbertura; }
    public int getPrazoEmDias() { return prazoEmDias; }
    public double getValor() { return valor; }
    public StatusOrdem getStatus() { return status; }

    public LocalDate getDataEstimadaEntrega() {
        return dataHoraAbertura.toLocalDate().plusDays(prazoEmDias);
    }

    public void cancelar(String motivo, LocalDateTime data) {
        this.motivoCancelamento = motivo;
        this.dataHoraCancelamento = data;
        this.status = StatusOrdem.CANCELADA;
    }

    public void fechar(FechamentoOrdemServico dados) {
        this.dadosFechamento = dados;
        this.status = StatusOrdem.FECHADA;
    }

    public String getNumero() {
        String prefixo = (equipamento instanceof Notebook) ? "NO" : "DE";

        String dt = String.format("%04d%02d%02d%02d%02d",
                dataHoraAbertura.getYear(),
                dataHoraAbertura.getMonthValue(),
                dataHoraAbertura.getDayOfMonth(),
                dataHoraAbertura.getHour(),
                dataHoraAbertura.getMinute()
        );

        String cpf = cliente.getCpfCnpj();

        if (cpf.length() == 11) {
            cpf = "000" + cpf;
        }

        return prefixo + dt + cpf;
    }

    @Override
    public String getId() {
        return getNumero();
    }
}
