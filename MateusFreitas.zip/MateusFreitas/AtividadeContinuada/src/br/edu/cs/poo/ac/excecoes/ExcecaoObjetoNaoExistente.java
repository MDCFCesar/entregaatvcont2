package br.edu.cs.poo.ac.excecoes;

public class ExcecaoObjetoNaoExistente extends Exception {

    private static final long serialVersionUID = 1L;

    public ExcecaoObjetoNaoExistente(String msg) {
        super(msg);
    }
}
