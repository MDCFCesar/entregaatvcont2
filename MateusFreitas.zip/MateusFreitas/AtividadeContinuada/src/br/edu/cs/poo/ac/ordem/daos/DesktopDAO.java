package br.edu.cs.poo.ac.ordem.daos;

import br.edu.cs.poo.ac.ordem.entidades.Desktop;
import br.edu.cs.poo.ac.utils.Registro;

public class DesktopDAO extends DAOGenerico {

    @Override
    protected Class<? extends Registro> getClasseEntidade() {
        return (Class<? extends Registro>) Desktop.class;
    }

    public Desktop buscar(String idTipoSerial) {
        return (Desktop) super.buscar(idTipoSerial);
    }

    public boolean incluir(Desktop desktop) {
        return super.incluir(desktop);
    }

    public boolean alterar(Desktop desktop) {
        return super.alterar(desktop);
    }

    public boolean excluir(String idTipoSerial) {
        return super.excluir(idTipoSerial);
    }

    public Desktop[] buscarTodos() {
        Registro[] lista = super.buscarTodos();
        Desktop[] retorno = new Desktop[lista.length];
        for (int i = 0; i < lista.length; i++) {
            retorno[i] = (Desktop) lista[i];
        }
        return retorno;
    }
}
