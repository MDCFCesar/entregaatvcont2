package br.edu.cs.poo.ac.ordem.entidades;
import java.io.Serializable;

/**O enum deve ter construtor privado, m�todos get p�blicos para os atributos codigo e nome, e um m�todo
p�blico e est�tico TipoOrdem getTipoOrdem(int codigo), que retorna o tipo de ordem correspondente ao
c�digo recebido como par�metro.**/ 
public enum TipoOrdem implements Serializable{
	MANUTENCAO(1,"Manuten��o"),
	CONFIGURACAO(2, "Configura��o"),
	UPGRADE(3, "Upgrade");
	
	private final int codigo;
	private final String nome;
	
	private TipoOrdem(int codigo, String nome){
		this.codigo = codigo;
		this.nome = nome;
	}

	public int getCodigo() {
		return codigo;
	}

	public String getNome() {
		return nome;
	}
	
	public static TipoOrdem getTipoOrdem(int codigo) {
		if (codigo == 1) {
	        return MANUTENCAO;
	    }
	    if (codigo == 2) {
	        return CONFIGURACAO;
	    }
	    if (codigo == 3) {
	        return UPGRADE;
	    }
        return null;
	}
	
}

