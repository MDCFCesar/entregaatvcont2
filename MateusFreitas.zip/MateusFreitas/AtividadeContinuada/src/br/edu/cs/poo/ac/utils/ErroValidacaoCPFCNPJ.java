package br.edu.cs.poo.ac.utils;

public enum ErroValidacaoCPFCNPJ {
	CPF_CNPJ_NULO_OU_BRANCO("CPF ou CNPJ est� nulo ou em branco"),	
	CPF_CNPJ_COM_TAMANHO_INVALIDO("CPF ou CNPJ com tamanho inv�lido"),
	CPF_CNPJ_COM_DV_INVALIDO("CPF ou CNPJ com d�gito verificador inv�lido"),
	CPF_CNPJ_COM_CARACTERES_INVALIDOS("CPF ou CNPJ com caracteres inv�lidos"),
	CPF_CNPJ_NAO_E_CPF_NEM_CNPJ("N�o � CPF nem CNJP");

    private final String mensagem;

    private ErroValidacaoCPFCNPJ(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }
}