package br.edu.cs.poo.ac.ordem.entidades;

public enum StatusOrdem {
    ABERTA,
    CANCELADA,
    FINALIZADA,
    FECHADA
}
