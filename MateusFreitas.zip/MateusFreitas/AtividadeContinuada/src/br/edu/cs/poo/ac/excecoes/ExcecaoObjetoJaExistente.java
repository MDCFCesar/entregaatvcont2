package br.edu.cs.poo.ac.excecoes;

public class ExcecaoObjetoJaExistente extends Exception {

    private static final long serialVersionUID = 1L;

    public ExcecaoObjetoJaExistente(String msg) {
        super(msg);
    }
}
