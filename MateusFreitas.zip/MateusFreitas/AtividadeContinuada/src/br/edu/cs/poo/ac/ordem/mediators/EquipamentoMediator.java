package br.edu.cs.poo.ac.ordem.mediators;

import br.edu.cs.poo.ac.ordem.daos.DesktopDAO;
import br.edu.cs.poo.ac.ordem.daos.NotebookDAO;
import br.edu.cs.poo.ac.ordem.entidades.Desktop;
import br.edu.cs.poo.ac.ordem.entidades.Notebook;
import br.edu.cs.poo.ac.ordem.entidades.Equipamento;
import br.edu.cs.poo.ac.utils.ListaString;

public class EquipamentoMediator {

    private static EquipamentoMediator instancia;

    private DesktopDAO desktopDAO;
    private NotebookDAO notebookDAO;

    private EquipamentoMediator() {
        desktopDAO = new DesktopDAO();
        notebookDAO = new NotebookDAO();
    }

    public static EquipamentoMediator getInstancia() {
        if (instancia == null) {
            instancia = new EquipamentoMediator();
        }
        return instancia;
    }


    public ResultadoMediator incluirDesktop(Desktop desk) {
        ResultadoMediator resultado = validarDesktop(desk);
        if (!resultado.isValidado()) return resultado;

        boolean sucesso = desktopDAO.incluir(desk);
        return new ResultadoMediator(resultado.isValidado(), sucesso, resultado.getMensagensErro());
    }

    public ResultadoMediator alterarDesktop(Desktop desk) {
        ResultadoMediator resultado = validarDesktop(desk);
        if (!resultado.isValidado()) return resultado;

        boolean sucesso = desktopDAO.alterar(desk);
        return new ResultadoMediator(resultado.isValidado(), sucesso, resultado.getMensagensErro());
    }

    public ResultadoMediator excluirDesktop(String idTipoSerial) {
        boolean sucesso = desktopDAO.excluir(idTipoSerial);
        return new ResultadoMediator(true, sucesso, new ListaString());
    }

    public Desktop buscarDesktop(String idTipoSerial) {
        return desktopDAO.buscar(idTipoSerial);
    }


    public ResultadoMediator incluirNotebook(Notebook note) {
        ResultadoMediator resultado = validarNotebook(note);
        if (!resultado.isValidado()) return resultado;

        boolean sucesso = notebookDAO.incluir(note);
        return new ResultadoMediator(resultado.isValidado(), sucesso, resultado.getMensagensErro());
    }

    public ResultadoMediator alterarNotebook(Notebook note) {
        ResultadoMediator resultado = validarNotebook(note);
        if (!resultado.isValidado()) return resultado;

        boolean sucesso = notebookDAO.alterar(note);
        return new ResultadoMediator(resultado.isValidado(), sucesso, resultado.getMensagensErro());
    }

    public ResultadoMediator excluirNotebook(String idTipoSerial) {
        boolean sucesso = notebookDAO.excluir(idTipoSerial);
        return new ResultadoMediator(true, sucesso, new ListaString());
    }

    public Notebook buscarNotebook(String idTipoSerial) {
        return notebookDAO.buscar(idTipoSerial);
    }



    public ResultadoMediator validarDesktop(Desktop desk){
        return validar(desk);
    }

    public ResultadoMediator validarNotebook(Notebook note) {
        return validar(note);
    }

    private ResultadoMediator validar(Notebook note){
        ListaString erros = new ListaString();

        if (note == null) {
            erros.adicionar("Dados do equipamento n�o informados.");
            return new ResultadoMediator(false, false, erros);
        }

        if (note.getSerial() == null || note.getSerial().trim().isEmpty()) {
            erros.adicionar("Serial n�o informado.");
        }

        if (note.getDescricao() == null || note.getDescricao().trim().isEmpty()) {
            erros.adicionar("Descri��o n�o informada.");
        } else if (note.getDescricao().length() < 10) {
            erros.adicionar("Descri��o deve ter ao menos 10 caracteres.");
        } else if (note.getDescricao().length() > 150) {
            erros.adicionar("Descri��o deve ter no m�ximo 150 caracteres.");
        }

        if (note.getValorEstimado() <= 0) {
            erros.adicionar("Valor estimado deve ser maior que zero.");
        }

        boolean validado = erros.tamanho() == 0;
        return new ResultadoMediator(validado, false, erros);
    }


	public ResultadoMediator validar(Desktop desk){
        ListaString erros = new ListaString();

        if (desk == null) {
            erros.adicionar("Dados do equipamento n�o informados.");
            return new ResultadoMediator(false, false, erros);
        }

        if (desk.getSerial() == null || desk.getSerial().trim().isEmpty()) {
            erros.adicionar("Serial n�o informado.");
        }

        if (desk.getDescricao() == null || desk.getDescricao().trim().isEmpty()) {
            erros.adicionar("Descri��o n�o informada.");
        } else if (desk.getDescricao().length() < 10) {
            erros.adicionar("Descri��o deve ter ao menos 10 caracteres.");
        } else if (desk.getDescricao().length() > 150) {
            erros.adicionar("Descri��o deve ter no m�ximo 150 caracteres.");
        }

        if (desk.getValorEstimado() <= 0) {
            erros.adicionar("Valor estimado deve ser maior que zero.");
        }

        boolean validado = erros.tamanho() == 0;

        return new ResultadoMediator(validado, false, erros);
    }
}
