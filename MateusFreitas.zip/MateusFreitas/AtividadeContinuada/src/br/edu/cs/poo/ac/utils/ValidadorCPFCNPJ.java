package br.edu.cs.poo.ac.utils;

public class ValidadorCPFCNPJ {

    // M�todo principal: identifica e valida CPF ou CNPJ
    public static ResultadoValidacaoCPFCNPJ validarCPFCNPJ(String cpfCnpj) {
        if (cpfCnpj == null || cpfCnpj.trim().isEmpty()) {
            return new ResultadoValidacaoCPFCNPJ(false, false, ErroValidacaoCPFCNPJ.CPF_CNPJ_NAO_E_CPF_NEM_CNPJ);
        }

        String valor = cpfCnpj.trim();

        if (isCPF(valor)) {
            ErroValidacaoCPFCNPJ erro = validarCPF(valor);
            if (erro == null) return new ResultadoValidacaoCPFCNPJ(true, false, null);
            return new ResultadoValidacaoCPFCNPJ(false, false, erro);
        }

        if (isCNPJ(valor)) {
            ErroValidacaoCPFCNPJ erro = validarCNPJ(valor);
            if (erro == null) return new ResultadoValidacaoCPFCNPJ(false, true, null);
            return new ResultadoValidacaoCPFCNPJ(false, false, erro);
        }

        return new ResultadoValidacaoCPFCNPJ(false, false, ErroValidacaoCPFCNPJ.CPF_CNPJ_NAO_E_CPF_NEM_CNPJ);
    }

    // Verifica se o valor tem formato de CPF (11 d�gitos)
    public static boolean isCPF(String valor) {
        return valor != null && valor.matches("\\d{11}");
    }

    // Verifica se o valor tem formato de CNPJ (14 d�gitos)
    public static boolean isCNPJ(String valor) {
        return valor != null && valor.matches("\\d{14}");
    }

    // Valida CPF (estrutura e d�gitos verificadores)
    public static ErroValidacaoCPFCNPJ validarCPF(String cpf) {
        if (cpf == null || !isCPF(cpf)) {
            return ErroValidacaoCPFCNPJ.CPF_CNPJ_NAO_E_CPF_NEM_CNPJ;
        }
        if (!isDigitoVerificadorValidoCPF(cpf)) {
            return ErroValidacaoCPFCNPJ.CPF_CNPJ_COM_DV_INVALIDO;
        }
        return null; // v�lido
    }

    // Valida CNPJ (estrutura e d�gitos verificadores)
    public static ErroValidacaoCPFCNPJ validarCNPJ(String cnpj) {
        if (cnpj == null || !isCNPJ(cnpj)) {
            return ErroValidacaoCPFCNPJ.CPF_CNPJ_NAO_E_CPF_NEM_CNPJ;
        }
        if (!isDigitoVerificadorValidoCNPJ(cnpj)) {
            return ErroValidacaoCPFCNPJ.CPF_CNPJ_COM_DV_INVALIDO;
        }
        return null; // v�lido
    }

    // ==============================
    // M�todos privados de valida��o
    // ==============================

    // Valida��o dos d�gitos verificadores do CPF
    private static boolean isDigitoVerificadorValidoCPF(String cpf) {
        try {
            int soma1 = 0, soma2 = 0;
            for (int i = 0; i < 9; i++) {
                int num = cpf.charAt(i) - '0';
                soma1 += num * (10 - i);
                soma2 += num * (11 - i);
            }

            int dig1 = 11 - (soma1 % 11);
            if (dig1 >= 10) dig1 = 0;
            soma2 += dig1 * 2;

            int dig2 = 11 - (soma2 % 11);
            if (dig2 >= 10) dig2 = 0;

            return dig1 == (cpf.charAt(9) - '0') && dig2 == (cpf.charAt(10) - '0');
        } catch (Exception e) {
            return false;
        }
    }

    // Valida��o dos d�gitos verificadores do CNPJ
    private static boolean isDigitoVerificadorValidoCNPJ(String cnpj) {
        try {
            int[] peso1 = {5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
            int[] peso2 = {6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};

            int soma1 = 0, soma2 = 0;
            for (int i = 0; i < 12; i++) {
                int num = cnpj.charAt(i) - '0';
                soma1 += num * peso1[i];
                soma2 += num * peso2[i];
            }

            int dig1 = soma1 % 11;
            dig1 = (dig1 < 2) ? 0 : 11 - dig1;
            soma2 += dig1 * peso2[12];
            int dig2 = soma2 % 11;
            dig2 = (dig2 < 2) ? 0 : 11 - dig2;

            return dig1 == (cnpj.charAt(12) - '0') && dig2 == (cnpj.charAt(13) - '0');
        } catch (Exception e) {
            return false;
        }
    }
}
