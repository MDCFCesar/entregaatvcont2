package br.edu.cs.poo.ac.utils;

import java.io.Serializable;

public interface Registro extends Serializable {
    String getId();
}
