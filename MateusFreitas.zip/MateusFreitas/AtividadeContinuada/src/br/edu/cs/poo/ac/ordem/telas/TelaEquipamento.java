package br.edu.cs.poo.ac.ordem.telas;

import javax.swing.*;

import br.edu.cs.poo.ac.ordem.entidades.Desktop;
import br.edu.cs.poo.ac.ordem.entidades.Notebook;
import br.edu.cs.poo.ac.ordem.mediators.EquipamentoMediator;
import br.edu.cs.poo.ac.ordem.mediators.ResultadoMediator;

import java.awt.*;
import java.awt.event.*;

public class TelaEquipamento extends JFrame {

    private JTextField txtTipo, txtSerial, txtDescricao, txtValor;
    private JComboBox<String> cbTipoEquip;

    private EquipamentoMediator mediator = EquipamentoMediator.getInstancia();

    public TelaEquipamento() {
        setTitle("Cadastro de Equipamentos");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lblTipo = new JLabel("Tipo:");
        lblTipo.setBounds(20, 20, 80, 25);
        add(lblTipo);

        cbTipoEquip = new JComboBox<>(new String[]{"Desktop", "Notebook"});
        cbTipoEquip.setBounds(120, 20, 200, 25);
        add(cbTipoEquip);

        JLabel lblSerial = new JLabel("Serial:");
        lblSerial.setBounds(20, 60, 80, 25);
        add(lblSerial);

        txtSerial = new JTextField();
        txtSerial.setBounds(120, 60, 200, 25);
        add(txtSerial);

        JLabel lblDescricao = new JLabel("Descri��o:");
        lblDescricao.setBounds(20, 100, 80, 25);
        add(lblDescricao);

        txtDescricao = new JTextField();
        txtDescricao.setBounds(120, 100, 200, 25);
        add(txtDescricao);

        JLabel lblValor = new JLabel("Valor Estimado:");
        lblValor.setBounds(20, 140, 120, 25);
        add(lblValor);

        txtValor = new JTextField();
        txtValor.setBounds(140, 140, 180, 25);
        add(txtValor);

        JButton btnIncluir = new JButton("Incluir");
        btnIncluir.setBounds(20, 200, 100, 30);
        add(btnIncluir);

        JButton btnAlterar = new JButton("Alterar");
        btnAlterar.setBounds(140, 200, 100, 30);
        add(btnAlterar);

        JButton btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(260, 200, 100, 30);
        add(btnExcluir);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(140, 250, 100, 30);
        add(btnBuscar);

        btnIncluir.addActionListener(e -> incluir());
        btnAlterar.addActionListener(e -> alterar());
        btnExcluir.addActionListener(e -> excluir());
        btnBuscar.addActionListener(e -> buscar());
    }

    private Desktop criarDesktop() {
        return new Desktop(txtSerial.getText(), txtDescricao.getText(), 
                           Double.parseDouble(txtValor.getText()));
    }

    private Notebook criarNotebook() {
        return new Notebook(txtSerial.getText(), txtDescricao.getText(), 
                            Double.parseDouble(txtValor.getText()));
    }

    private void incluir() {
        try {
            ResultadoMediator r;
            if (cbTipoEquip.getSelectedItem().equals("Desktop")) {
                r = mediator.incluirDesktop(criarDesktop());
            } else {
                r = mediator.incluirNotebook(criarNotebook());
            }

            JOptionPane.showMessageDialog(this, r.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }

    private void alterar() {
        try {
            ResultadoMediator r;
            if (cbTipoEquip.getSelectedItem().equals("Desktop")) {
                r = mediator.alterarDesktop(criarDesktop());
            } else {
                r = mediator.alterarNotebook(criarNotebook());
            }
            JOptionPane.showMessageDialog(this, r.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }

    private void excluir() {
        String id = txtSerial.getText();
        ResultadoMediator r;

        if (cbTipoEquip.getSelectedItem().equals("Desktop")) {
            r = mediator.excluirDesktop(id);
        } else {
            r = mediator.excluirNotebook(id);
        }

        JOptionPane.showMessageDialog(this, r.toString());
    }

    private void buscar() {
        String id = txtSerial.getText();

        if (cbTipoEquip.getSelectedItem().equals("Desktop")) {
            Desktop d = mediator.buscarDesktop(id);
            if (d == null) {
                JOptionPane.showMessageDialog(this, "Desktop n�o encontrado.");
            } else {
                txtDescricao.setText(d.getDescricao());
                txtValor.setText(String.valueOf(d.getValorEstimado()));
            }
        } else {
            Notebook n = mediator.buscarNotebook(id);
            if (n == null) {
                JOptionPane.showMessageDialog(this, "Notebook n�o encontrado.");
            } else {
                txtDescricao.setText(n.getDescricao());
                txtValor.setText(String.valueOf(n.getValorEstimado()));
            }
        }
    }

    public static void main(String[] args) {
        new TelaEquipamento().setVisible(true);
    }
}
