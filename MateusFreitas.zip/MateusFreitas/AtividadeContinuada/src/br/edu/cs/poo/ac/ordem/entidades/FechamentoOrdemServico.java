package br.edu.cs.poo.ac.ordem.entidades;

import java.io.Serializable;
import java.time.LocalDate;

import br.edu.cs.poo.ac.utils.Registro;

public class FechamentoOrdemServico implements Serializable, Registro {

    private static final long serialVersionUID = 1L;

    private String numeroOrdem;
    private LocalDate dataFechamento;
    private boolean paga;
    private String relatorioFinal;

    public FechamentoOrdemServico(String numeroOrdem, LocalDate dataFechamento, boolean paga, String relatorioFinal) {
        this.numeroOrdem = numeroOrdem;
        this.dataFechamento = dataFechamento;
        this.paga = paga;
        this.relatorioFinal = relatorioFinal;
    }

    public String getNumeroOrdem() { return numeroOrdem; }
    public LocalDate getDataFechamento() { return dataFechamento; }
    public boolean isPaga() { return paga; }
    public String getRelatorioFinal() { return relatorioFinal; }

    @Override
    public String getId() {
        return numeroOrdem;
    }
}
