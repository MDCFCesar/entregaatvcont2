package br.edu.cs.poo.ac.ordem.daos;

import java.io.Serializable;

import br.edu.cesarschool.next.oo.persistenciaobjetos.CadastroObjetos;
import br.edu.cs.poo.ac.utils.Registro;

public abstract class DAOGenerico {

    protected CadastroObjetos cadastroObjetos;

    public DAOGenerico() {
        
        this.cadastroObjetos = new CadastroObjetos(getClasseEntidade());
    }

    
    protected abstract Class<? extends Registro> getClasseEntidade();

    // --------------------- CRUD GEN�RICO -------------------------

    public Registro buscar(String id) {
        return (Registro) cadastroObjetos.buscar(id);
    }

    public boolean incluir(Registro registro) {
        String id = registro.getId();
        if (buscar(id) == null) {
            cadastroObjetos.incluir((Serializable) registro, id);
            return true;
        }
        return false;
    }

    public boolean alterar(Registro registro) {
        String id = registro.getId();
        if (buscar(id) != null) {
            cadastroObjetos.alterar((Serializable) registro, id);
            return true;
        }
        return false;
    }

    public boolean excluir(String id) {
        if (buscar(id) != null) {
            cadastroObjetos.excluir(id);
            return true;
        }
        return false;
    }

    public Registro[] buscarTodos() {
        Object[] lista = cadastroObjetos.buscarTodos();

        if (lista == null || lista.length == 0) {
            return new Registro[0];
        }

        Registro[] resultado = new Registro[lista.length];
        for (int i = 0; i < lista.length; i++) {
            resultado[i] = (Registro) lista[i];
        }

        return resultado;
    }
}
