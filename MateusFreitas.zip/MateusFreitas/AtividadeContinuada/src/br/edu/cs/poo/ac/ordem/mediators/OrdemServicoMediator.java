package br.edu.cs.poo.ac.ordem.mediators;

import java.time.LocalDateTime;

import br.edu.cs.poo.ac.ordem.daos.DAORegistro;
import br.edu.cs.poo.ac.ordem.entidades.*;

public class OrdemServicoMediator {

    private static OrdemServicoMediator instancia;

    private DAORegistro<OrdemServico> daoOrdem;
    private DAORegistro<FechamentoOrdemServico> daoFechamento;

    private OrdemServicoMediator() {
        daoOrdem = new DAORegistro<>();
        daoFechamento = new DAORegistro<>();
    }

    public static OrdemServicoMediator getInstancia() {
        if (instancia == null) instancia = new OrdemServicoMediator();
        return instancia;
    }

    public ResultadoMediator incluir(DadosOrdemServico dados) {
        ListaString erros = new ListaString();

        if (dados == null) {
            erros.incluir("Dados inv�lidos.");
            return new ResultadoMediator(false, false, erros);
        }

        return new ResultadoMediator(true, true, erros);
    }

    public ResultadoMediator cancelar(String numero, String motivo, LocalDateTime data) {
        ListaString erros = new ListaString();

        OrdemServico ordem = daoOrdem.buscar(numero);

        if (ordem == null) {
            erros.incluir("Ordem n�o encontrada.");
            return new ResultadoMediator(false, false, erros);
        }

        ordem.cancelar(motivo, data);
        daoOrdem.alterar(ordem);

        return new ResultadoMediator(true, true, erros);
    }

    public ResultadoMediator fechar(FechamentoOrdemServico fechamento) {
        ListaString erros = new ListaString();

        if (fechamento == null) {
            erros.incluir("Dados inv�lidos.");
            return new ResultadoMediator(false, false, erros);
        }

        OrdemServico ordem = daoOrdem.buscar(fechamento.getNumeroOrdem());

        if (ordem == null) {
            erros.incluir("Ordem n�o encontrada.");
            return new ResultadoMediator(false, false, erros);
        }

        ordem.fechar(fechamento);
        daoFechamento.incluir(fechamento);
        daoOrdem.alterar(ordem);

        return new ResultadoMediator(true, true, erros);
    }

    public OrdemServico buscar(String numero) {
        return daoOrdem.buscar(numero);
    }
}
