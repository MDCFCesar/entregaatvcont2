package br.edu.cs.poo.ac.ordem.entidades;

import br.edu.cs.poo.ac.utils.Registro;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public abstract class Equipamento implements Registro {

    private String serial;
    private String descricao;
    private boolean ehNovo;
    private double valorEstimado;

    // Cada subclass (Desktop/Notebook) implementa esse m�todo
    public abstract String getIdTipo();

    @Override
    public String getId() {
        return getIdTipo() + serial;
    }
}
