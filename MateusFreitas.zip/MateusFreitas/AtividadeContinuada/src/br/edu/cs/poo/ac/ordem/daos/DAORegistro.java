package br.edu.cs.poo.ac.ordem.daos;

import java.util.HashMap;

public class DAORegistro<T> {

    private HashMap<String, T> dados = new HashMap<>();

    public void incluir(T obj) {
        try {
            String id = (String) obj.getClass().getMethod("getId").invoke(obj);
            dados.put(id, obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public T buscar(String id) {
        return dados.get(id);
    }

    public void alterar(T obj) {
        incluir(obj);
    }
}
