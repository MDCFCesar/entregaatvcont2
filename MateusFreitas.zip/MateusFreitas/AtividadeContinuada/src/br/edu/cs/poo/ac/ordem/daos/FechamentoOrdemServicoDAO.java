package br.edu.cs.poo.ac.ordem.daos;

import br.edu.cs.poo.ac.ordem.entidades.FechamentoOrdemServico;
import br.edu.cs.poo.ac.utils.Registro;

public class FechamentoOrdemServicoDAO extends DAOGenerico {

    @Override
    protected Class<? extends Registro> getClasseEntidade() {
        return FechamentoOrdemServico.class;
    }

    public FechamentoOrdemServico buscar(String numeroOrdem) {
        return (FechamentoOrdemServico) super.buscar(numeroOrdem);
    }

    public boolean incluir(FechamentoOrdemServico fechamento) {
        return super.incluir(fechamento);
    }

    public boolean alterar(FechamentoOrdemServico fechamento) {
        return super.alterar(fechamento);
    }

    public boolean excluir(String numeroOrdem) {
        return super.excluir(numeroOrdem);
    }

    public FechamentoOrdemServico[] buscarTodos() {
        Registro[] lista = super.buscarTodos();
        FechamentoOrdemServico[] retorno = new FechamentoOrdemServico[lista.length];
        for (int i = 0; i < lista.length; i++) {
            retorno[i] = (FechamentoOrdemServico) lista[i];
        }
        return retorno;
    }
}
