package br.edu.cs.poo.ac.ordem.daos;

import br.edu.cs.poo.ac.ordem.entidades.OrdemServico;
import br.edu.cs.poo.ac.utils.Registro;

public class OrdemServicoDAO extends DAOGenerico {

    @Override
    protected Class<? extends Registro> getClasseEntidade() {
        return OrdemServico.class;
    }

    public OrdemServico buscar(String numero) {
        return (OrdemServico) super.buscar(numero);
    }

    public boolean incluir(OrdemServico os) {
        return super.incluir(os);
    }

    public boolean alterar(OrdemServico os) {
        return super.alterar(os);
    }

    public boolean excluir(String numero) {
        return super.excluir(numero);
    }

    public OrdemServico[] buscarTodos() {
        Registro[] lista = super.buscarTodos();
        OrdemServico[] retorno = new OrdemServico[lista.length];
        for (int i = 0; i < lista.length; i++) {
            retorno[i] = (OrdemServico) lista[i];
        }
        return retorno;
    }
}
